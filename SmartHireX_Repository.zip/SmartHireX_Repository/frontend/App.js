
import React from "react";

function App() {
  return (
    <div style={{padding: "40px", fontFamily: "Arial"}}>
      <h1>SmartHireX</h1>
      <p>AI-Powered Intelligent Hiring Platform</p>

      <h2>Features</h2>
      <ul>
        <li>Resume Parsing</li>
        <li>AI Semantic Matching</li>
        <li>Candidate Ranking</li>
        <li>Skill Gap Analysis</li>
      </ul>
    </div>
  );
}

export default App;
