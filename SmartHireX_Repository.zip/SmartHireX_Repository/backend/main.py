
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Candidate(BaseModel):
    name: str
    skills: list

@app.get("/")
def home():
    return {"message": "Welcome to SmartHireX API"}

@app.post("/rank")
def rank_candidate(candidate: Candidate):
    score = len(candidate.skills) * 10
    return {
        "candidate": candidate.name,
        "score": score,
        "status": "Ranked Successfully"
    }
